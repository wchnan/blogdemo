//
//  ViewController.swift
//  TagNavigationDemo
//
//  Created by 苟欣 on 16/5/11.
//  Copyright © 2016年 苟欣. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var underLineView: UIView!
    // MARK: - 自定义变量
    var pageViewController:UIPageViewController!//代表pageviewcontroller，会为他赋值
    var pageContentViewControllers = [PageContentViewController]()//保存所有的控制器
    var titleArray = ["第一超长","第二个","第三个也超长"]
    var inDragging = false
    var currentPageIndex = 0 {
        willSet(newValue){
            inDragging = false
            print("当前四page\(newValue)")
            setUnselectForIndex(currentPageIndex, withColor: UIColor.blackColor())
            setSelectForIndex(newValue, withColor: UIColor.redColor())
        }
    }
    var willGoToPageIndex = 0 {
        willSet(newValue){
            inDragging = true
            self.currentUnderLineCenterX = self.underLineView.center.x
            print("willgoto page \(newValue)")
        }
    }
    var currentUnderLineCenterX = CGFloat(0)
    let offsetWidth = UIScreen.mainScreen().bounds.size.width * 0.33
    // MARK: - 生命周期
    override func viewDidLoad() {
        super.viewDidLoad()
        initPageContentViewControllers()
        self.pageViewController = self.childViewControllers.first as! UIPageViewController
        ///设置pageviewcontroller的datasource和delegate
        self.pageViewController.delegate   = self
        self.pageViewController.dataSource = self
        ///设置当前的viewcontroller为FirstViewController
        self.pageViewController.setViewControllers([self.pageContentViewControllers.first!], direction: .Forward, animated: true, completion: nil)
        
        for view in self.pageViewController.view.subviews{
            if(view.isKindOfClass(UIScrollView)){
                view.backgroundColor = UIColor.redColor()
                (view as! UIScrollView).delegate = self
            }
        }
    
    }
    @IBOutlet weak var firstBtn: UIButton!
    @IBOutlet weak var secondBtn: UIButton!
    @IBOutlet weak var thirdBtn: UIButton!
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        self.currentUnderLineCenterX = firstBtn.center.x
    }
    ///把vc从storyboard中取出来
    func initPageContentViewControllers(){
        let firstVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("FirstViewController") as! PageContentViewController
        firstVc.pageIndex = 0
        self.pageContentViewControllers.append(firstVc)
        
        let secondVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SecondViewController") as! PageContentViewController
        secondVc.pageIndex = 1
        self.pageContentViewControllers.append(secondVc)
        
        let thirdVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("ThirdViewController") as! PageContentViewController
        thirdVc.pageIndex = 2
        self.pageContentViewControllers.append(thirdVc)
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setSelectForIndex(index:Int, withColor color:UIColor){
        switch index {
        case 0:
            self.firstBtn.setTitleColor(color, forState: .Normal)
        case 1:
            self.secondBtn.setTitleColor(color, forState: .Normal)
        case 2:
            self.thirdBtn.setTitleColor(color, forState: .Normal)
        default:
            break
        }
    }
  
    func setUnselectForIndex(index:Int,withColor color:UIColor){
        switch index {
        case 0:
            self.firstBtn.setTitleColor(color, forState: .Normal)
        case 1:
            self.secondBtn.setTitleColor(color, forState: .Normal)
        case 2:
            self.thirdBtn.setTitleColor(color, forState: .Normal)
        default:
            break
        }
    }

    @IBAction func clickedThird(sender: UIButton) {
        self.pageViewController.setViewControllers([self.pageContentViewControllers[2]], direction: .Forward, animated: true, completion: nil)
        self.currentPageIndex = 2
        UIView.animateWithDuration(0.2, animations: {
            self.underLineView.center.x = self.thirdBtn.center.x
        })
    }
    @IBAction func clickedSecond(sender: UIButton) {
        self.pageViewController.setViewControllers([self.pageContentViewControllers[1]], direction: currentPageIndex == 0 ? .Forward:.Reverse, animated: true, completion: nil)
        self.currentPageIndex = 1
        
        UIView.animateWithDuration(0.2, animations: {
            self.underLineView.center.x = self.secondBtn.center.x
        })
    }
    @IBAction func clickedFirst(sender: UIButton) {
        self.pageViewController.setViewControllers([self.pageContentViewControllers[0]], direction: .Reverse, animated: true, completion: nil)
        self.currentPageIndex = 0
        UIView.animateWithDuration(0.2, animations: {
            self.underLineView.center.x = self.firstBtn.center.x
        })
    }

}

//处理滑动
extension ViewController:UIPageViewControllerDelegate{
    //即将移动到某个vc
    func pageViewController(pageViewController: UIPageViewController, willTransitionToViewControllers pendingViewControllers: [UIViewController]) {
        self.willGoToPageIndex = (pendingViewControllers.first as! PageContentViewController).pageIndex
    }
    
    func pageViewController(pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if(completed){
            currentPageIndex = willGoToPageIndex
        }
    }
    

    
  
    
}
///提供当前viewcontroller的前一个和后一个vc是谁
extension ViewController:UIPageViewControllerDataSource{
    ///当前viewcontroller的前一个vc是谁，这样当我们向前滑动时就是到该显示什么视图了
    func pageViewController(pageViewController: UIPageViewController, viewControllerBeforeViewController viewController: UIViewController) -> UIViewController? {
        let currentIndex = (viewController as! PageContentViewController).pageIndex
        if(currentIndex - 1 >= 0){///前面还存在vc，返回这个vc
            return pageContentViewControllers[currentIndex - 1]
        }else{//不存在，返回nil
            return nil
        }
    }
    ///当前viewcontroller的后一个vc是谁，这样当我们向后滑动时就是到该显示什么视图了
    func pageViewController(pageViewController: UIPageViewController, viewControllerAfterViewController viewController: UIViewController) -> UIViewController? {
        let currentIndex = (viewController as! PageContentViewController).pageIndex
        if(currentIndex + 1 < self.pageContentViewControllers.count){//后面还有vc,返回vc
            return pageContentViewControllers[currentIndex + 1]
        }else{//不存在，返回nil
            return nil
        }
    }
}



extension ViewController:UIScrollViewDelegate{
    func scrollViewDidScroll(scrollView: UIScrollView) {
        if(!inDragging){ return }
       //print(scrollView.contentOffset)
        var xoffset = (scrollView.contentOffset.x - scrollView.bounds.size.width)
        if(xoffset < 0){ xoffset = -xoffset }
       
        let scale = xoffset / scrollView.bounds.size.width
        
        if(willGoToPageIndex > currentPageIndex){
            self.underLineView.center.x = self.currentUnderLineCenterX + offsetWidth * scale
        }else{
            self.underLineView.center.x = self.currentUnderLineCenterX - offsetWidth * scale
        }
        let colorselect   = UIColor(red: scale, green: 0, blue: 0, alpha: 1.0)
        let colorUnselect = UIColor(red: (1-scale), green: 0, blue: 0, alpha: 1.0)
        setSelectForIndex(willGoToPageIndex, withColor: colorselect)
        setUnselectForIndex(currentPageIndex, withColor: colorUnselect)
        
    }
    
}



