//
//  PageContentViewController.swift
//  TagNavigationDemo
//
//  Created by 苟欣 on 16/5/11.
//  Copyright © 2016年 苟欣. All rights reserved.
//

import UIKit

class PageContentViewController: UIViewController {

    var pageIndex = 0

}
