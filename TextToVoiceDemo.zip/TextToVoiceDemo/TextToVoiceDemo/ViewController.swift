//
//  ViewController.swift
//  TextToVoiceDemo
//
//  Created by 苟欣 on 16/5/12.
//  Copyright © 2016年 苟欣. All rights reserved.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {
    @IBAction func speak(sender: UIButton) {
        let utterance = AVSpeechUtterance(string: "农业不发达，要用金坷垃。日本资源太缺乏必须要用金坷垃，掺了金坷垃，不浪费蒸发，掺了金坷垃能吸收两米下的氮磷钾，世界肥料都涨价，我们都要金坷垃，肥料掺了金坷垃不流失不浪费蒸发，肥料掺金坷垃金坷垃能吸收氮磷钾，肥料掺了金坷垃一代能顶两袋撒，肥料掺了金坷垃坷垃小麦亩产一千八，农业不发达，要用金坷垃，日本资源太缺乏必须要用金坷垃，掺了金坷垃，不浪费蒸发，掺了金坷垃能吸收两米下的氮磷钾，世界肥料都涨价，我们都要金坷垃，肥料掺了金坷垃不流失不浪费蒸发，肥料掺金坷垃金坷垃能吸收氮磷钾，非洲农业不发达，必须要用金坷垃，日本资源太缺乏必须有金坷垃，肥料掺了金坷垃一代能顶两袋撒，日本肥料掺了金坷垃粮食不进口啦，非洲农业不发达，必须要用金坷垃，日本资源太缺乏必须有金坷垃，亩产一千八，拉拉，日本鬼子真不傻，不能给了他金坷垃，给了他对美国农业，对非洲危害大，非洲农业不发达，必须要用金坷垃，日本资源太缺乏必须有金坷垃，肥料掺了金坷垃一代能顶两袋撒，日本肥料掺了金坷垃粮食不进口啦，我要金坷垃我要金坷垃，日本粮食有了金坷垃再不进口啦，非洲不发达我们支援他，你们日本鬼子不要想别想金坷垃。")
        print(AVSpeechUtteranceDefaultSpeechRate)
        utterance.voice = AVSpeechSynthesisVoice(language: "zh-TW")
        utterance.rate = 0.55
        utterance.pitchMultiplier = 2.0
        let speechSynthesizer = AVSpeechSynthesizer()
        speechSynthesizer.speakUtterance(utterance)
    }

    @IBOutlet weak var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

