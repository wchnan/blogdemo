//
//  MyView.swift
//  XibDemo
//
//  Created by 苟欣 on 16/4/30.
//  Copyright © 2016年 苟欣. All rights reserved.
//

import UIKit
@IBDesignable//设置了这个，能让MyView在storyboard中显示
class MyView: UIView {

    @IBOutlet var contentView: UIView!
   
   override init(frame: CGRect) {
        super.init(frame: frame)
        initViewFromNib()
    }
    
   required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initViewFromNib()
   }

    private func initViewFromNib(){
        //需要这句代码，不能直接写UINib(nibName: "MyView", bundle: nil)
        //，不然不能在storyboard中显示
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "MyView", bundle: bundle)
        self.contentView = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        self.contentView.frame = bounds
        self.addSubview(contentView)
    }
}
