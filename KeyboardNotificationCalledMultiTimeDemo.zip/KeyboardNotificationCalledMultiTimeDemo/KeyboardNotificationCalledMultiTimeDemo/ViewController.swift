//
//  ViewController.swift
//  KeyboardNotificationCalledMultiTimeDemo
//
//  Created by 苟欣 on 16/5/3.
//  Copyright © 2016年 苟欣. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // MARK: - IBOoutlet
    @IBOutlet weak var containerViewCenterConstrait: NSLayoutConstraint!
    @IBOutlet weak var textFieldContainerView: UIView!
    @IBOutlet weak var textField: UITextField!
    
    // MARK: - life circle
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ViewController.keyboardWillAppear(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ViewController.keyboardWillHidden(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
    }
    
    func keyboardWillAppear(notify:NSNotification){
       
        if let userInfo = notify.userInfo{
            guard let frameBeginKey = userInfo[UIKeyboardFrameBeginUserInfoKey]?.CGRectValue().size.height where frameBeginKey > 0 else{ return }
             print(notify)
            
            if let keyboardHeight = userInfo[UIKeyboardFrameEndUserInfoKey]?.CGRectValue().size.height{
                let blankHeight = (UIScreen.mainScreen().bounds.height - 310)/2.0
                let offset  = keyboardHeight - blankHeight
                if(offset < 0){ return }//足够高，不用移动
                UIView.animateWithDuration(0.1, animations: {
                    self.containerViewCenterConstrait.constant = 0//防止切换输入法，累加高度
                    self.containerViewCenterConstrait.constant -= offset
                    self.view.layoutIfNeeded()
                    }, completion: nil)
            }
        }
    }
    
    func keyboardWillHidden(notify:NSNotification){
        UIView.animateWithDuration(0.25, animations: {
            self.containerViewCenterConstrait.constant = 0
            self.view.layoutIfNeeded()
            }, completion: nil)
    }

    
    @IBAction func tapedBlankArea(sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

